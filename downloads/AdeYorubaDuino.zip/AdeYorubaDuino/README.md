# AdeYorubaDuino

*AdeYorubaDuino* is an Arduino library that lets you write Arduino code in *Yoruba language*.  
It provides Yoruba aliases for Arduino keywords, constants, functions, and popular libraries like Servo, Stepper, LCD, DHT, I2C, SPI, EEPROM, WiFi, Bluetooth, RF24,nrf24l01,and IR Remote.

---

## ✨ Features
- Write Arduino code using Yoruba keywords.
- Supports *basic Arduino functions* (digital/analog, serial, timing).
- Includes Yoruba wrappers for:
  - Servo (SAVO)
  - Stepper (motoIgbese)
  - LCD (IFIHAN)
  - DHT (OORU)
  - I2C/Wire (OKAN)
  - SPI (AYEKA)
  - EEPROM (IRANTI)
  - WiFi (AIFOJU) (optional, for ESP boards)
  - Bluetooth (ERO)
  - IR Remote (AFIRANSE)
  - nrf24lo1 (AFIRANSE RADIO)
- Easy to learn for beginners in Yoruba-speaking communities.

---

## 📦 Installation
1. Download the latest release as a .zip.
2. Open Arduino IDE → Sketch → Include Library → Add .ZIP Library....
3. Select AdeYorubaDuino.zip.
4. Include it in your sketch:
   ```cpp
#fikun <AdeYorubaDuino.h>
## ⚠️ License & Intellectual Property
The AdeYorubaDuino Dictionary is original work by [Ayelangbe Adeyinka Samuel].  
It is shared for educational purposes only.  
Redistribution, modification, or commercial use without permission is prohibited.
## 📖 Yoruba ↔ English Dictionary
The full AdeYorubaDuino Yoruba-to-English coding dictionary is included for reference.  

👉 [Download Dictionary (Word)](docs/AdeYorubaDuino_Dictionary.docx)  
👉 [Download Dictionary (PDF)](docs/AdeYorubaDuino_Dictionary.pdf)