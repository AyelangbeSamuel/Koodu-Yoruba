#ifndef ADE_YORUBA_DUINO_H
#define ADE_YORUBA_DUINO_H

#include <Arduino.h>

// =======================
// Yoruba Preprocessor Aliases
// =======================
#define pejade #define     // define
#define fikun #include     // include
#define pada return
#define juju void          // Yoruba alias for void
#define ja break
#define idiwo constrain
#define gbesoke pow

//#define setup bereEto
//#define loop bereAtunse
// =======================
// Yoruba Data Types
// =======================
#define iye int
#define iyePipin float
#define iyePipinGiga double
#define oro char
#define oroPupo String
#define iyeGiga long
#define iyeGigaRere unsigned long
#define iyeKukuru short
#define lotito bool
#define EXI HEX
#define aiyi const
#define ejo byte
#define aropo struct 
#define niKukuru min
#define niGiga max
#define rutu sqrt
#define siIye toInt
#define ipeleoro substring
#define otito true
#define iro false

// =======================
// Constants
// =======================
#define JADE OUTPUT
#define WOLE INPUT
#define FA_SOKE INPUT_PULLUP
#define TAN HIGH
#define PA LOW
#define gigun length

// =======================
// Function Aliases
// =======================
// Timing
#define duro delay
#define duroFun delayMicroseconds
#define kaAago pulseIn
#define daako map
#define perese millis

// Digital & Analog
#define koAbere digitalWrite
#define kaAbere digitalRead
#define koAmon analogWrite
#define kaAmon analogRead
#define ipoAbere pinMode
#define dun tone
#define maDun noTone

// Serial Communication
#define bereAworan(...) Serial.begin(__VA_ARGS__)
#define teAworan(...) Serial.print(__VA_ARGS__)
#define teAworanLaini(...) Serial.println(__VA_ARGS__)
#define kaAworan Serial.read
#define kaAworanLaini Serial.readStringUntil
#define geku trim

// =======================
// Conditions
// =======================
#define ti if
#define bibeko else
#define bibekoTi else if
#define nigbaTi while
#define fun for
#define TABI ||
#define ATI &&
#define baje ==
#define feedi  <=
#define feeje >=
#define baju >
#define feto <

// =======================
// User-defined Yoruba functions
// =======================
juju bereEto();
juju bereAtunse();

// =======================
// Servo (SAVO) Aliases
// =======================
#ifdef LO_SAVO
  #include <Servo.h>
  #define SAVO Servo
  #define soPo attach
  #define yaSoPo detach
  #define ko write
  #define kaIgun read
  #define koIdurofun writeMicroseconds
#endif

// =======================
// Stepper (motoIgbese) Aliases
// =======================
#ifdef LO_MOTO_IGBESE
  #include <Stepper.h>
  #define motoIgbese Stepper
  #define seEre setSpeed
  #define gbeIgbese step
#endif

// =======================
// LCD (IFIHAN) Aliases
// =======================
#ifdef LO_IFIHAN
  #include <LiquidCrystal.h>
  #define IFIHAN LiquidCrystal
  #define bereIfihan begin
  #define koIfihan print
  #define ipoIfihan setCursor
  #define nuIfihan clear
#endif

// =======================
// DHT (OORU) Aliases
// =======================
#ifdef LO_OORU
  #include <DHT.h>
  #define OORU DHT
  #define bereOoru begin
  #define kaOtutu readTemperature
  #define kaOoru readHumidity
  #define abereOoru DHTPIN
  #define iruOoru DHTTYPE
  #define rara isnan
#endif

// =======================
// I2C / Wire (OKAN) Aliases
// =======================
#ifdef LO_OKAN
  #include <Wire.h>
  #define OKAN Wire
  #define bereOkan begin
  #define bereIfiranse beginTransmission
  #define koIfiranse write
  #define pariIfiranse endTransmission
  #define bereGbigbaLati requestFrom
  #define kaIfiranse read
#endif

// =======================
// SPI (AYEKA) Aliases
// =======================
#ifdef LO_AYEKA
  #include <SPI.h>
  #define AYEKA SPI
  #define bereAyeka begin
  #define ranseAyeka transfer
  #define pariAyeka end
#endif

// =======================
// EEPROM (IRANTI) Aliases
// =======================
#ifdef LO_IRANTI
  #include <EEPROM.h>
  #define IRANTI EEPROM
  #define kaIranti read
  #define koIranti write
  #define tunseIranti update
  #define gigunIranti length
#endif

// =======================
// WiFi (AIFOJU) Aliases
// =======================
#ifdef LO_AIFOJU
  #include <WiFi.h>
  #define AIFOJU WiFi
  #define bereAsopo begin
  #define ipoAsopo status
  #define ipAgbegbe localIP
  #define yaAsopo disconnect
#endif

// =======================
// Bluetooth (ERO) Aliases
// =======================
#ifdef LO_ERO
  #include <SoftwareSerial.h>
  #define ERO SoftwareSerial
  #define bereEro begin
  #define eroWa available
  #define kaEro read
  #define koEro write
#endif
// =======================
// IR Remote (AFIRANSE) Aliases — latest IRremote library
// =======================
#ifdef LO_AFIRANSE
  #include <IRremote.hpp>
  #define AFIRANSE IrReceiver       // Receiver object
  #define Itumosi decode_results    // Compatibility alias
  #define bereGbigbaAfiranse enableIRIn   // Start receiver
  #define tuAfiranse decode         // Try decode
  #define tunBereAfiranse resume 
  #define itumoIFIGbigba IrReceiver.decodedIRData
  #define ofin protocol
  #define ase command
  #define itumoLodidiGbigba decodedRawData
  #define JEKI_INA_FESI ENABLE_LED_FEEDBACK
#endif
  
  // Resume after decode
// =======================
// nRF24L01 (AFIRANSE_RADA) Aliases
// =======================
#ifdef LO_AFIRANSE_RADIO
#include <RF24.h>
// Yoruba-style aliases
#define AFIRANSE_RADIO RF24
#define bereAfiranseRadio begin
#define koRadio write
#define gbaRadio available
#define kaRadio read
#define siOpaIfiranseKiko setWritingPipe
#define siOpaIfiranseGbigba setReadingPipe
#define bereGbigbo startListening
#define gbigbo    Listening
#define daGbigbaduro stopListening
#define bereOpaIfiranseKiko openWritingPipe
#define bereOpaIfiranseKika openReadingPipe
#define tanRadio powerUp
#define paRadio powerDown
#define teIpoRadio printDetails
#endif
  // Yoruba aliases for decoded data
 
// =======================
// Map Yoruba entry points to Arduino core
// =======================

#endif