#include <Arduino.h>
#include "AdeYorubaDuino.h"

// The standard Arduino entry point setup must be defined.
// It calls the user's aliased function, bereEto.
void setup() {
  // Check if the user has defined bereEto Yoruba setup
  // This call works because the function is declared in the .h file.
  bereEto();
}

// The standard Arduino entry point loop must be defined.
// It calls the user's aliased function, bereAtunse.
void loop() {
  // Check if the user has defined bereAtunse Yoruba loop
  // This call works because the function is declared in the .h file.
  bereAtunse();
}