#include<AdeYorubaDuino.h>
 iye abereIyi=A0;
 iye amoranIyi;
juju bereEto(){
 bereAworan(9600);
ipoAbere(abereIyi,WOLE);

}
juju bereAtunse(){

 amoranIyi=kaAmon(abereIyi);
 teAworan("AMONRAN:");
 teAworanLaini(amoranIyi);

}