#define LO_SAVO
#include<AdeYorubaDuino.h>

SAVO savomi;
iye ipo=0;
iye ipoSavo(9);

juju bereEto(){

 bereAworan(9600);
 savomi.soPo(ipoSavo);

}

juju bereAtunse(){

fun (ipo=0; ipo feedi 180; ipo=ipo+1){

 savomi.ko(ipo);
 duro(15);

}

fun (ipo=180; ipo feeje 0; ipo=ipo-1 ){

    savomi.ko(ipo);
    duro(15);
}

}