#include<AdeYorubaDuino.h>

iye ina=13;
iye iseju=1000;

 juju bereEto(){

 ipoAbere(ina,JADE);

 }

 juju bereAtunse(){

 koAbere(ina, TAN);
 duro(iseju);
 koAbere(ina, PA);
 duro(iseju);
 
 
 }