#define LO_SAVO
#include<AdeYorubaDuino.h>
SAVO savo;
iye abereSavo=9;

juju bereEto(){

savo.soPo(abereSavo);
bereAworan(9600);
teAworan("SAVO TI BERE ISE 👍");

}

juju bereAtunse(){

savo.ko(0);
duro(500);
savo.ko(90);
duro(500);
savo.ko(180);
duro(500);

}