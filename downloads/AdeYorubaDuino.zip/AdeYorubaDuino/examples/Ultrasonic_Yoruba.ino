#include<AdeYorubaDuino.h>
iye isoro=9;
iye igbo=10;

iyeGiga akoko;
iye ijina;

juju bereEto(){
ipoAbere(isoro,JADE);
ipoAbere(igbo,WOLE);
bereAworan(9600);

}


juju bereAtunse(){

koAbere(isoro,PA);
duroFun(2);
koAbere(isoro,TAN);
duroFun(10);
koAbere(isoro,PA);


akoko=kaAago(igbo,TAN);
ijina=akoko*0.342/2;
teAworan("IJINA:");
teAworan(ijina);
teAworan("CM");


}